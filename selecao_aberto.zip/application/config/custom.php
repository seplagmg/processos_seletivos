<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['nome']='Processos Seletivos MG';
//$config['email']='edital.brumadinho@social.mg.gov.br';
$config['email']='naoresponda@planejamento.mg.gov.br';
$config['administrador']='';

//configuração de email SMTP
$config['smtp_host'] = '';
$config['smtp_user'] = '';
$config['smtp_pass'] = '';